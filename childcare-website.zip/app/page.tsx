import Component from "../zubair-ai-school"

export default function Page() {
  return <Component />
}
